#!/bin/bash
#Licensed to https://www.hostingtermurah.net/
#Script by PR Aiman

red='\e[1;31m'
blue='\e[1;34m'
green='\e[0;32m'
NC='\e[0m'
echo "Connecting to Server..."
sleep 0.5
echo "Checking Permision..."
sleep 0.4
CEK=PR Aiman
if [ "$CEK" != "PR Aiman" ]; then
		echo -e "${red}Permission Denied!${NC}";
        echo $CEK;
        exit 0;
else
echo -e "${green}Permission Accepted...${NC}"
sleep 1
clear
fi
clear
echo " "
echo " "
echo " "
read -p "Input USERNAME to change password: " username
egrep "^$username" /etc/passwd >/dev/null
if [ $? -eq 0 ]; then
read -p "Input new PASSWORD for user $username: " password

clear
echo "Connecting to Server..."
sleep 0.5
echo "Generating New Password..."
sleep 0.5
  egrep "^$username" /etc/passwd >/dev/null
  echo -e "$password\n$password" | passwd $username
  clear
  echo " "
  echo " "
  echo " "
  echo "-------------------------------------------"
  echo -e "Password for user ${blue}$username${NC} successfully changed."
  echo -e "The new Password for user ${blue}$username${NC} is ${red}$password${NC}"
  echo "-------------------------------------------"
  echo " "
  echo " "
  echo " "

else
echo " "
echo -e "Username ${red}$username${NC} not found in your VPS"
echo " "
exit 0
fi