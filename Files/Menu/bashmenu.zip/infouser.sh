echo Script Created By PR Aiman
echo User : test expired on date : 02 Apr 2020